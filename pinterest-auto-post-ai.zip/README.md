# Pinterest Auto Post + AI (Backend)

This is a ready-to-deploy Node.js backend that:
- Connects to Pinterest via OAuth
- Generates titles/descriptions/hashtags with AI (OpenAI)
- Schedules posts with BullMQ/Redis
- Uploads media and creates Pins automatically at the scheduled time

## Quick Start

1) **Clone/Upload this repo** to your GitHub.
2) Create a `.env` from `.env.example` and fill values (in Render/Railway, add as Environment variables).
3) Deploy two services from this same repo:
   - **Server**: runs `npm start` (Express API & OAuth routes)
   - **Worker**: runs `npm run worker` (background scheduler/Pin posting)
4) In your Pinterest developer account, set the redirect URI to:
   `https://YOUR-BACKEND-DOMAIN/auth/pinterest/callback`
5) Visit `/auth/pinterest` to connect your Pinterest account.
6) Use `/schedule/csv` to upload a CSV of images to schedule.

## CSV Format
```
image_url,title,description,hashtags,board_id,link,scheduled_date,scheduled_time,filename
https://example.com/img1.jpg,,"",,123456,https://yoursite.com/1,,
```
- If `title/description` are empty, AI will generate them.
- If `scheduled_date/time` are empty, the server will auto-assign time slots.
- `filename` is optional and helps AI if the image URL can't be fetched by the model.

## Endpoints
- `GET /auth/pinterest` → start OAuth
- `GET /auth/pinterest/callback` → save token (you must store securely; this template returns JSON)
- `POST /schedule/csv` → multipart/form-data with field `file` (CSV)
  - The server enqueues jobs to Redis (BullMQ).
- Worker fetches jobs at the right time and posts to Pinterest.

## Important
- Keep your API keys safe. Never commit real secrets to Git.
- Start in **sandbox** mode until everything works.
- Add retries/backoff and logging (already enabled in BullMQ config).

Good luck 🚀
